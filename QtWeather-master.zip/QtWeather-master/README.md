# 这是一个基于Qt的获取天气程序

界面及其简单，仅仅通过纯文字来显示天气信息

## 构建

### 生成环境

* Qt6
* msvc2019
* OpenSSL-Win64

### 构建步骤

1. 生成Release程序
2. 复制Release程序到单独的文件夹，并使用windeployqt复制dll依赖
3. 手动复制OpenSSL的dll文件，libcrypto-1_1-x64.dll、libssl-1_1-x64.dll

### 注意事项

1. 对于打包好的程序不能正常运行（缺少dll文件），可以使用windos自带的资源管理器查看其dll依赖
2. 更好的dll查看器为ProcessExplorer
3. 初次打包程序时踩到的坑，当时电脑上没有安装OpenSSL，安装了MySQL并有其环境变量，程序依然可以正常联网，原因在于MySQL的环境变量中有libcrypto-1_1-x64.dll、libssl-1_1-x64.dll这两个dll，此时依然需要手动复制这两个文件到打包程序中

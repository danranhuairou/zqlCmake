#ifndef WEATHER_H
#define WEATHER_H

#include <qwidget.h>
#include <qmenu.h>
#include <qaction.h>
#include <qcombobox.h>
#include <qlabel.h>
#include <qvector.h>
#include <qstring.h>
#include <qnetworkaccessmanager.h>
#include <qnetworkreply.h>

class Weather : public QWidget {
    Q_OBJECT

public:
    Weather(QWidget* parent = nullptr);
    ~Weather();
    QMenu* GetMenu();

private:
    //天气设置菜单
    QMenu* m_menu;
    QAction* m_actionSetCity;
    QAction* m_actionShow;

    //显示天气信息的三个控件
    QComboBox* m_comboBoxSelect;
    QLabel* m_labelHead;
    QLabel* m_labelInfo;

    //存储着天气信息
    QVector<QString> m_weaInfo;

    //获取city的天气
    void ParseWeather(QString city);

private slots:
    //天气预报的城市设置
    void s_SetCity();
    //显示第几天的天气
    void s_Day(int);

private:
    void Initialize();

    //http相关
private:
    QNetworkAccessManager* m_naManager;

    void InitializeHttp();
    //发送http请求，以获取city的天气
    void GetWeather(QString city);
    //在str中查找target，并返回target所对应的数据
    //每次查找都会删除找到内容之前的内容
    QString FindData(QString& str, const QString& target);
    //QString to 星期几
    QString ToWeek(QString str);
private slots:
    //http请求完成时调用此函数
    void replyFinished(QNetworkReply* reply);
};
#endif // WEATHER_H

#include "weather.h"
#include <qpalette.h>
#include <qrect.h>
#include <qinputdialog.h>
#include <QNetworkRequest>
#include <QNetworkReply>

Weather::Weather(QWidget* parent)
    : QWidget(parent)
{
    Initialize();
    InitializeHttp();
}

Weather::~Weather()
{
    delete m_actionSetCity;
    delete m_actionShow;
    delete m_menu;

    delete m_comboBoxSelect;
    delete m_labelHead;
    delete m_labelInfo;
}

void Weather::Initialize() {
    resize(300, 200);
    //设置背景色
    setAutoFillBackground(true);
    QPalette pal(palette());
    pal.setColor(QPalette::Window, qRgb(124, 223, 248));
    setPalette(pal);

    //menu
    m_menu = new QMenu(this);
    m_menu->setTitle(tr("天气"));

    m_actionShow = new QAction(this);
    m_actionShow->setText(tr("显示天气插件"));
    m_actionShow->setCheckable(true);
    m_actionShow->setChecked(true);
    m_actionSetCity = new QAction(this);
    m_actionSetCity->setText(tr("设置城市"));

    m_menu->addAction(m_actionShow);
    m_menu->addAction(m_actionSetCity);

    //三个控件设置
    QRectF rect(0, 0, size().width(), 0);

    rect.setHeight(25);
    m_labelHead = new QLabel(this);
    m_labelHead->setGeometry(rect.toRect());

    rect.setTop(rect.bottom());
    rect.setHeight(20);
    m_comboBoxSelect = new QComboBox(this);
    m_comboBoxSelect->setGeometry(rect.toRect());
    m_comboBoxSelect->addItem(QString());
    m_comboBoxSelect->addItem(QString());
    m_comboBoxSelect->addItem(QString());
    m_comboBoxSelect->addItem(QString());

    rect.setTop(rect.bottom());
    rect.setBottom(size().height());
    m_labelInfo = new QLabel(this);
    m_labelInfo->setGeometry(rect.toRect());

    //connect
    connect(m_actionSetCity, SIGNAL(triggered()), this, SLOT(s_SetCity()));
    connect(m_actionShow, SIGNAL(toggled(bool)), this, SLOT(setVisible(bool)));
    connect(m_comboBoxSelect, SIGNAL(currentIndexChanged(int)), this, SLOT(s_Day(int)));
}

QMenu* Weather::GetMenu() {
    return m_menu;
}

void Weather::s_SetCity() {
    bool ok;
    QString city = QInputDialog::getText(this, tr("设置城市"), tr("请输入一个城市"), QLineEdit::Normal, 0, &ok);
    GetWeather(city);
}

void Weather::s_Day(int index) {
    //更新日期
    QString str;
    int pos = index * 10 + 3 + 1;

    //星期几
    str = ToWeek(m_weaInfo[pos++]) + '\n';
    str += "白天天气：" + m_weaInfo[pos++] + '\n';
    str += "晚间天气：" + m_weaInfo[pos++] + '\n';
    str += "白天温度：" + m_weaInfo[pos++] + '\n';
    str += "晚间温度：" + m_weaInfo[pos++] + '\n';
    str += "白天风力：" + m_weaInfo[pos++] + '\n';
    str += "晚间风力：" + m_weaInfo[pos++] + '\n';
    str += "白天风向：" + m_weaInfo[pos++] + '\n';
    str += "晚间风向：" + m_weaInfo[pos++];

    //天气信息的显示
    m_labelInfo->setText(str);
}

//http相关
void Weather::InitializeHttp() {
    m_naManager = new QNetworkAccessManager(this);
    connect(m_naManager, &QNetworkAccessManager::finished,
        this, &Weather::replyFinished);

    //获取默认城市的天气
    GetWeather("哈尔滨");
}

void Weather::GetWeather(QString city) {
    //仅需要发送获取城市编码的URL即可
    //获取天气在replyFinished函数中处理
    QString url = "https://restapi.amap.com/v3/config/district?key=fa1228bc6667a259801d247e44dbb88e&keywords=";
    url += city;
    url += "&subdistrict = 0&extensions=base";
    m_naManager->get(QNetworkRequest(url));
}

void Weather::replyFinished(QNetworkReply* reply) {
    static bool sign = true;
    QString str = reply->readAll();
    if (sign) {
        int adcode = FindData(str, "adcode").toInt();
        //url
        QString url = "https://restapi.amap.com/v3/weather/weatherInfo?key=fa1228bc6667a259801d247e44dbb88e&city=";
        url += QString::number(adcode);
        url += "&extensions=all&output=json";

        m_naManager->get(QNetworkRequest(url));
        sign = !sign;
    }
    else {
        ParseWeather(str);
        sign = !sign;
    }
}

void Weather::ParseWeather(QString json) {
    m_weaInfo.clear();

    //Keyword
    static const QVector<QString>keyword = {
        "city","province","reporttime",
        "date","week","dayweather","nightweather","daytemp","nighttemp","daywind","nightwind","daypower","nightpower"
    };

    //共有3 + 4 * 10个数据
    for (size_t i = 0; i < 3; i++) {
        m_weaInfo.push_back(FindData(json, keyword[i]));
    }
    for (size_t j = 0; j < 4; j++)
        for (size_t i = 0; i < 10; i++) {
            m_weaInfo.push_back(FindData(json, keyword[i + 3]));
        }

    QString str;
    //示例：黑龙江省双鸭山市\t更新日期 2021/04/19
    str = m_weaInfo[1] + "省" + m_weaInfo[0] + " 更新日期：" + m_weaInfo[2];
    m_labelHead->setText(str);

    //设置 下拉选择列表
    for (size_t i = 0; i < 4; i++) {
        str = m_weaInfo[3 + i * 10];
        m_comboBoxSelect->setItemText(int(i), str);
    }
    s_Day(0);
}

QString Weather::FindData(QString& str, const QString& target) {
    size_t begin = str.indexOf(target);
    if (begin == -1)
        return "";
    //找到了target，移到其尾部
    begin += target.length() + 1;
    //找接下来的第一组双引号，其内即为所要数据
    begin = str.indexOf('\"', begin) + 1;
    size_t end = str.indexOf('\"', begin);
    if (begin == -1 || end == -1)
        return "";

    QString res = str.mid(begin, end - begin);
    //删除之前的内容
    str = str.mid(end);
    return res;
}

QString Weather::ToWeek(QString str) {
    switch (str[0].toLatin1() - '0') {
    case 0:
        return "星期一";
    case 1:
        return "星期二";
    case 2:
        return "星期三";
    case 3:
        return "星期四";
    case 4:
        return "星期五";
    case 5:
        return "星期六";
    case 6:
    default:
        return "星期日";
    }
}

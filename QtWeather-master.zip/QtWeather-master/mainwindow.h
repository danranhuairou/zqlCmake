#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <qmenubar.h>
#include <qmenu.h>
#include "weather.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    //menu
    QMenuBar* m_menubar;
    QMenu* m_menuSet;

    Weather* m_weather;

private:
    void Initialize();
};
#endif // MAINWINDOW_H

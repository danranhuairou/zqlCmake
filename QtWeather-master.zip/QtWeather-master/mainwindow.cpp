#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    Initialize();
}

MainWindow::~MainWindow()
{
    delete m_weather;

    //menu
    delete m_menuSet;
    delete m_menubar;
}

void MainWindow::Initialize() {
    resize(400, 300);

    m_weather = new Weather(this);
    m_weather->setGeometry(0, 25, m_weather->size().width(), m_weather->size().height());

    //menu
    m_menubar = new QMenuBar(this);
    this->setMenuBar(m_menubar);

    m_menuSet = new QMenu(m_menubar);
    m_menuSet->setTitle(tr("设置"));

    m_menubar->addAction(m_menuSet->menuAction());
    m_menuSet->addAction(m_weather->GetMenu()->menuAction());
}
